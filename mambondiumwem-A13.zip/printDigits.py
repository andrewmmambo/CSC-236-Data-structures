#-------------------------------------------------------------------------------
# authored by: Marima Andrew Mambondiumwe
# Assignment- A13 : Recursion, C++ and Python
#
# File Name:        printDigit.py
# Purpose:  This program asks the user for a number
#        that is in base 10 and the new number base.
#        This program uses recursion to convert the
#        number, in which it keeps dividing the number
#        by the base until it reaches a number between
#        zero and the base, at which point it stops. It
#        outputs the digits during that process.
#
#-------------------------------------------------------------------------------

def printDigits(num, base):

    assert (base > 1), 'There is an Error, The base given is not greater than one'
    if num < base:
        print str(num) + " "
    else:
        printDigits(num / base, base)
        print str(num) % base + " "


def main():                 # this defines the function
    num = 0                 # this initialises the num to 0
    base = 0                # this initialises the base to 0
    num = int(raw_input("What is the number to convert?: "))            # this prompts the user for input
    base = int(raw_input("What is the new number base for that number?: ")) # this prompts the user for input
    printDigits(num, base)

if __name__ == '__main__':
    main()                  # calls the main function
